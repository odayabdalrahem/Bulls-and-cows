/*
 *     The bulls and cows game
 *
 *     (Read ASSIGNMENT1.txt carefully before you start coding)
 *
 *     NOTE: Only int's, if, while and functions needed!
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

#define TEST true     // If true run tests (only), else run program, change to "false" only after
                      // implementing functions
#define DEBUG true    // If true, print number to guess to make debugging easier

// ----------- Declare functions used in main ----------

// Generates a 4-digit random number with no repeated digits
// (digits in range 1-9)
int get_random_4digit();

// Returns number of bulls in guessed number
int count_bulls(int guess, int answer);

// Returns number of bulls and cows in guessed number
// Comment: Counting both bulls and cows together is simpler to implement,
// instead of just counting cows. The number of cows you get by combining
// this function and count_bulls
int count_cows_and_bulls(int guess, int answer);

// Get input from player
int get_player_guess();

// Testing of functions, see far below
void test();


/*
 *  Program starts here
 */
int main(void) {
  
    srand((unsigned int) time(NULL));     // Init random number generator

    if (TEST) {
        test();
        return 0;
    }

    int answer = get_random_4digit();

    if (DEBUG) {
        printf("Answer is %d\n", answer);
    }

    printf("Welcome to Bulls and Cows\n");
    printf("Try to guess a 4 digit number with digits 1-9\n");
    printf("and no repeating digits (-1 to abort).\n\n");
    printf("Bulls = correct digit(s) in correct positions.\n");
    printf("Cows = correct digit(s).\n\n");

    bool aborted = false;
    int n_guess = 0;
    int guess = 0;
    int bulls = 0;
    int cows = 0;

    // ----- The game loop ------

    // TODO Use functions (and more) to implement the game
    // TODO Try to sketch one round, then surround with a loop.

    // --- End game loop --------

    if (aborted) {
        printf("Game aborted\n");
    } else {
        printf("Done, number was %d and you needed %d guesses\n", answer, n_guess);
    }

    return 0;
}

// ------- Functions definitions --------------------------------

// This one's for free...
int get_player_guess() {
    int guess;
    printf("Guess > ");
    scanf("%d", &guess);
    return guess;
}

// Put the remaining function definitions here


// ---------------- The function to do all tests --------------------

// This macro is used for testing. It expects v1 and v2 shall be equal and print OK or Not OK
#define CHECK_IF_EQUALS(v1, v2) printf((v1) == (v2) ? "OK\n" : "Not OK!!!\n")

void test() {

    // TODO Uncomment on at the time and test

    /*
    // if you intend to check if the guess was correct, use and test the n_digits-function
    CHECK_IF_EQUALS(n_digits(123), 3);
    CHECK_IF_EQUALS(n_digits(12345), 5);
    CHECK_IF_EQUALS(n_digits(1623945), 7);
    */
  
    /*
    CHECK_IF_EQUALS(get_digit_at_position(4321, 1), 1);
    CHECK_IF_EQUALS(get_digit_at_position(4321, 3), 3);
    CHECK_IF_EQUALS(get_digit_at_position(4321, 4), 4);

    CHECK_IF_EQUALS(digit_is_in(2637, 2), true);
    CHECK_IF_EQUALS(digit_is_in(2637, 4), false);

    printf("Random answer %d\n", get_random_4digit());
    printf("Random answer %d\n", get_random_4digit());
    printf("Random answer %d\n", get_random_4digit());

    CHECK_IF_EQUALS(count_bulls(1827, 7812), 1);
    CHECK_IF_EQUALS(count_bulls(2647, 2837), 2);

    CHECK_IF_EQUALS(count_cows_and_bulls(1827, 7812), 4);
    CHECK_IF_EQUALS(count_cows_and_bulls(2647, 2837), 2);
    */
}
